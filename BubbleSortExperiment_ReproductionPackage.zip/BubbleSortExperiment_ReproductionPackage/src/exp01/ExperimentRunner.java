
package exp01;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class ExperimentRunner {

    // setup -> array sizes, repetitions and warm-ups
    private static final int[] SIZES = {100, 500, 1000};
    private static final int REPETITIONS = 10;
    private static final int WARMUP_RUNS = 5;

    public static void main(String[] args) throws IOException {

        // algo -> the 3 Bubble Sort implementations
        Sorter<Integer>[] algorithms = new Sorter[] {
            new BubbleSortPassPerItem<Integer>(),
            new BubbleSortUntilNoChange<Integer>(),
            new BubbleSortWhileNeeded<Integer>()
        };

        // algo names -> identify results in the CSV file
        String[] names = {
            "BubbleSortPassPerItem",
            "BubbleSortUntilNoChange",
            "BubbleSortWhileNeeded"
        };

        // input types -> sorted, random and reversed arrays
        String[] inputTypes = {"SORTED", "RANDOM", "REVERSED"};

        // results -> create folder to save measurements
        File folder = new File("results");
        folder.mkdirs();

        // CSV file -> save all experiment measurements
        FileWriter writer = new FileWriter("results/measurements.csv");

        // CSV columns -> information saved for each measurement
        writer.write("algorithm,inputType,arraySize,repetition,timeNs\n");

        // random generator -> same seed for duplicatable inputs
        Random random = new Random(42);

        System.out.println("Starting experiment...");

        // warm up -> run algorithms before measuring their speed
        for (int a = 0; a < algorithms.length; a++) {

            for (int w = 0; w < WARMUP_RUNS; w++) {

                Integer[] warmup = generateArray(1000, "RANDOM", random);

                algorithms[a].sort(warmup);
            }
        }

        System.out.println("Warm-up completed.");

        // experiment -> test every array size
        for (int size : SIZES) {

            // test every input type 
            for (String type : inputTypes) {

                System.out.println("Testing " + size + " items: " + type);

                // repetitions -> repeat each test 10 times
                for (int repetition = 1; repetition <= REPETITIONS; repetition++) {

                    // generate input -> same original array for all algo
                    Integer[] original = generateArray(size, type, random);

                    // test each algo
                    for (int a = 0; a < algorithms.length; a++) {

                        // copy array -> every algo gets the same input
                        Integer[] items = original.clone();

                        // start timer -> measure sorting time only
                        long start = System.nanoTime();

                        algorithms[a].sort(items);

                        // stop timer -> calculate execution time
                        long end = System.nanoTime();

                        long time = end - start;

                        // check result -> make sure array is sorted
                        if (!isSorted(items)) {
                            throw new IllegalStateException(names[a] + " failed!");
                        }

                        // save measurement -> write one row into CSV
                        writer.write(
                            names[a] + "," +
                            type + "," +
                            size + "," +
                            repetition + "," +
                            time + "\n"
                        );
                    }
                }
            }
        }

        // close file -> make sure all measurements are saved
        writer.close();

        System.out.println("Experiment completed!");
        System.out.println("Measurements saved in results/measurements.csv");
    }


    // generate arrays -> sorted, random or reversed
    private static Integer[] generateArray(int size, String type, Random random) {

        Integer[] items = new Integer[size];

        // fill array -> numbers from 1 to size
        for (int i = 0; i < size; i++) {
            items[i] = i + 1;
        }

        // random array -> mix the numbers
        if (type.equals("RANDOM")) {

            for (int i = size - 1; i > 0; i--) {

                int j = random.nextInt(i + 1);

                // swap numbers -> change their positions
                Integer temp = items[i];
                items[i] = items[j];
                items[j] = temp;
            }
        }

        // reversed array -> put numbers in descending order
        else if (type.equals("REVERSED")) {

            for (int i = 0; i < size / 2; i++) {

                // swap first and last -> reverse the array
                Integer temp = items[i];
                items[i] = items[size - 1 - i];
                items[size - 1 - i] = temp;
            }
        }

        return items;
    }


    // check array -> verify that numbers are in ascending order
    private static boolean isSorted(Integer[] items) {

        for (int i = 1; i < items.length; i++) {

            if (items[i - 1] > items[i]) {
                return false;
            }
        }

        return true;
    }
}
